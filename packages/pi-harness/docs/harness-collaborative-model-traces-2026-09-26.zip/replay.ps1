param(
    [string]$Scenario,
    [string]$RepoRoot = 'E:/Projects/pi-packages',
    [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
foreach ($trace in $manifest.traces) {
    $path = Join-Path $PSScriptRoot $trace.file
    if ((Get-FileHash $path -Algorithm SHA256).Hash.ToLower() -ne $trace.exportSha256) {
        throw "Trace digest mismatch: $($trace.file)"
    }
    $events = @(Get-Content $path | ForEach-Object { $_ | ConvertFrom-Json })
    $last = @($events | Where-Object { $_.type -eq 'message_end' -and $_.message.role -eq 'assistant' })[-1]
    if ($last.message.stopReason -ne 'stop' -or $last.message.provider -ne '3z' -or $last.message.model -ne 'gpt-5.6-terra') {
        throw "Incomplete or wrong-model trace: $($trace.file)"
    }
}
if ($VerifyOnly) {
    "Verified $($manifest.traces.Count) exported actual-model traces."
    return
}
$selected = @($manifest.traces | Where-Object { $_.file -eq "$Scenario.jsonl" })
if ($Scenario -eq 'stages') { $selected = @($manifest.traces | Where-Object { $_.file -like 'stage-turn*.jsonl' }) }
if (-not $selected.Count) { throw 'Choose a trace basename, or stages for the three-turn session.' }
foreach ($source in $manifest.sources) {
    $path = Join-Path $RepoRoot $source.path
    if ((Get-FileHash $path -Algorithm SHA256).Hash.ToLower() -ne $source.sha256) {
        throw "Instruction source changed: $($source.path)"
    }
}
$run = Join-Path ([IO.Path]::GetTempPath()) ("harness-replay-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $run | Out-Null
$probe = Get-Content (Join-Path $PSScriptRoot 'probe.ts') -Raw
$probe = $probe.Replace('E:/Projects/pi-packages', $RepoRoot.Replace('\', '/')).Replace($manifest.originalFixtureRoot, $run.Replace('\', '/'))
[IO.File]::WriteAllText((Join-Path $run 'probe.ts'), $probe)
Copy-Item (Join-Path $PSScriptRoot 'restoration-case.md') $run
$request = Get-Content (Join-Path $PSScriptRoot 'handler-request.yaml') -Raw
$request = $request.Replace($manifest.originalFixtureRoot, $run.Replace('\', '/'))
[IO.File]::WriteAllText((Join-Path $run 'handler-request.yaml'), $request)
Push-Location $run
try {
    foreach ($trace in $selected) {
        $prompt = $trace.prompt.Replace('E:/Projects/pi-packages', $RepoRoot.Replace('\', '/')).Replace($manifest.originalFixtureRoot, $run.Replace('\', '/'))
        $skill = Join-Path $RepoRoot "packages/pi-harness/skills/$($trace.skill)/SKILL.md"
        $piArgs = @('--no-extensions', '--no-skills', '--skill', $skill, '--no-context-files', '--model', '3z/gpt-5.6-terra', '--thinking', 'low', '--mode', 'json', '-p')
        if ($trace.mode -eq 'router') {
            $piArgs += @('-e', './probe.ts', '--no-tools')
        } else {
            $piArgs += @('--tools', 'read')
            if ($trace.mode -eq 'handler') {
                $piArgs += @('--system-prompt', (Join-Path $RepoRoot 'packages/pi-harness/agents/handler.md'))
                $prompt = '@handler-request.yaml'
            }
        }
        if ($Scenario -eq 'stages') { $piArgs += @('--session', (Join-Path $run 'stage-session.jsonl')) } else { $piArgs += '--no-session' }
        & pi @piArgs $prompt > (Join-Path $run $trace.file)
        if ($LASTEXITCODE -ne 0) { throw "Pi exited $LASTEXITCODE for $($trace.file)" }
    }
} finally { Pop-Location }
"Replay logs: $run (inspect assistant message_end and tool_execution_*; do not treat exit 0 alone as a pass)."
