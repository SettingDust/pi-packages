import { appendFileSync } from "node:fs";
import { createHash } from "node:crypto";
import activateHarness from "E:/Projects/pi-packages/packages/pi-harness/extensions/pi-harness.ts";

export default function activate(pi) {
  const wrapped = new Proxy(pi, {
    get(target, key, receiver) {
      if (key !== "on") return Reflect.get(target, key, receiver);
      return (event, listener) => target.on(event, async (...args) => {
        const result = await listener(...args);
        if (event === "before_agent_start") {
          const prompt = result?.systemPrompt ?? "";
          appendFileSync("C:/Users/WINDOWS/AppData/Local/Temp/harness-model-evidence-ef1ef26443b649348a926dd4a02da56d/instruction-load.jsonl", JSON.stringify({
            promptLength: prompt.length,
            promptSha256: createHash("sha256").update(prompt).digest("hex"),
            routerHeader: prompt.startsWith("You are the Pi Harness Router."),
            routeRule: prompt.includes("route approval authorizes no stage"),
            confirmationRule: prompt.includes("A path, readiness claim, intent agreement"),
            exceptionRule: prompt.includes("Under existing explicit authorization only"),
            skills: args[0].systemPromptOptions.skills?.map(s => ({ name: s.name, filePath: s.filePath })) ?? [],
          }) + "\n");
        }
        return result;
      });
    },
  });
  activateHarness(wrapped);
}
