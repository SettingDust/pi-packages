# Invoice export case
Accepted local Spec: The invoice export has a column `balance` equal to unpaid invoice amount at export time. Formatting and stable column order are part of the existing contract.
Existing user authorization: Investigate whether a small correction to the current export is needed to preserve the above contract. Do not edit code during this assessment.
Observed shipped result: On invoices with a partial payment, the export currently emits the original invoice total in `balance`, while the accepted Spec expects the remaining unpaid amount.
Proposed next action: Correct the calculation for this column with an in-scope test on partial payments. A teammate also proposes adding a `net_paid` field and a new currency-rate service while touching the export.
