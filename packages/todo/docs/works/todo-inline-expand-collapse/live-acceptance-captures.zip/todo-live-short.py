import json, os, pathlib, re, shutil, tempfile, threading, time
from winpty import PtyProcess
BASE = pathlib.Path(tempfile.gettempdir()) / 'todo-inline-accept-446409dc'
OUT = pathlib.Path(tempfile.mkdtemp(prefix='todo-live-short-'))
ANSI = re.compile(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])')
print('ARTIFACT_DIR', OUT)
for mode in ('regular','fullscreen'):
    agent = OUT / (mode + '-agent'); agent.mkdir()
    for name in ('auth.json','models-store.json','settings.json'): shutil.copyfile(BASE/'agent'/name, agent/name)
    env = dict(os.environ, PI_CODING_AGENT_DIR=str(agent), PI_OFFLINE='1', PI_SKIP_VERSION_CHECK='1', PI_TELEMETRY='0', OPENAI_API_KEY='sk-todo-acceptance-dummy')
    args = ['node','node_modules/@earendil-works/pi-coding-agent/dist/cli.js','--session',str(BASE/'fixture.jsonl'),'--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','-e','packages/todo/src/index.ts','--tui-mode',mode]
    p = PtyProcess.spawn(args,cwd='E:/Projects/pi-packages',env=env,dimensions=(35,100))
    chunks=[]; stop=threading.Event()
    def reader():
        while not stop.is_set():
            try: chunks.append(p.read(65536))
            except Exception: break
    t=threading.Thread(target=reader,daemon=True); t.start()
    events=[]
    def step(name, data=None, wait=.3, size=None):
        start=len(chunks)
        if size: p.setwinsize(*size)
        if data is not None: p.write(data)
        time.sleep(wait)
        raw=''.join(chunks[start:]); text=ANSI.sub('',raw).replace('\r','')
        lines=[line for line in text.splitlines() if any(s in line for s in ('FINAL_DESCRIPTION','Step 16','Plan','Build','Empty task','Warning','PASTE','Todos ','New session','Resume','session','Session','(1/39)','(2/39)'))]
        e={'step':name,'bytes':len(raw.encode()),'final': 'FINAL_DESCRIPTION_SENTINEL' in text,'selected': '\x1b[48;2;58;58;74' in raw,'lines':lines[-8:]}; events.append(e)
        print(mode,json.dumps(e,ensure_ascii=False))
        return e
    try:
        step('ready',wait=2.5); step('entry','/todo-details\r'); step('plan right','\x1b[C'); step('build down','\x1b[B'); step('build right','\x1b[C')
        step('25x8 resize',size=(8,25),wait=.7)
        found=None
        for i in range(180):
            e=step('page '+str(i+1),'\x1b[6~',wait=.035)
            if e['final']: found=i+1; break
        print('SHORT_FINAL',mode,found)
        step('navigate down','\x1b[B',wait=.5)
        step('restore 100x35',size=(35,100),wait=.7)
        step('escape','\x1b')
        step('reentry','/todo-details\r')
        step('shortcut kitty T','\x1b[116;6u',wait=.5)
        step('shortcut kitty t shifted','\x1b[84;6u',wait=.5)
        step('escape after shortcuts','\x1b')
        step('new','/new\r',wait=1)
        step('resume','/resume\r',wait=.8)
        step('resume list down','\x1b[B',wait=.5)
        step('resume list escape','\x1b',wait=.5)
    finally:
        stop.set()
        if p.isalive(): p.terminate()
        t.join(timeout=3)
        (OUT/(mode+'.vt')).write_text(''.join(chunks),encoding='utf-8')
        (OUT/(mode+'.json')).write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf-8')
        print('PROCESS',mode,'terminated',not p.isalive())
