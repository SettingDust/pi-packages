import json, os, pathlib, re, shutil, tempfile, threading, time
from winpty import PtyProcess

ROOT = pathlib.Path('E:/Projects/pi-packages')
BASE = pathlib.Path(tempfile.gettempdir()) / 'todo-inline-accept-446409dc'
OUT = pathlib.Path(tempfile.mkdtemp(prefix='todo-live-followup-'))
fixture = BASE / 'fixture.jsonl'
assert fixture.exists()
ANSI = re.compile(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])')

def plain(s):
    return ANSI.sub('', s).replace('\r', '')

def run(mode):
    agent = OUT / (mode + '-agent')
    agent.mkdir()
    for name in ('auth.json', 'models-store.json', 'settings.json'):
        shutil.copyfile(BASE / 'agent' / name, agent / name)
    env = dict(os.environ, PI_CODING_AGENT_DIR=str(agent), PI_OFFLINE='1', PI_SKIP_VERSION_CHECK='1', PI_TELEMETRY='0', OPENAI_API_KEY='sk-todo-acceptance-dummy')
    args = ['node', 'node_modules/@earendil-works/pi-coding-agent/dist/cli.js', '--session', str(fixture), '--no-extensions', '--no-skills', '--no-prompt-templates', '--no-context-files', '-e', 'packages/todo/src/index.ts', '--tui-mode', mode]
    p = PtyProcess.spawn(args, cwd=str(ROOT), env=env, dimensions=(35, 100))
    raw = []
    stop = threading.Event()
    def reader():
        while not stop.is_set():
            try:
                s = p.read(65536)
                if s:
                    raw.append(s)
                else:
                    time.sleep(.04)
            except Exception:
                break
    t = threading.Thread(target=reader, daemon=True)
    t.start()
    events = []
    def step(name, data=None, wait=.55, resize=None):
        start = len(raw)
        if resize:
            p.setwinsize(*resize)
        if data is not None:
            p.write(data)
        time.sleep(wait)
        value = ''.join(raw[start:])
        text = plain(value)
        matches = [x for x in text.splitlines() if any(k in x for k in ('Todos ', 'Plan', 'Build', 'Empty task', 'Step 16', 'FINAL_DESCRIPTION', 'EDITOR_SENTINEL', 'PASTE_SENTINEL', 'No matching models', 'models from', '/todo-details', 'session', 'Session', 'Select', 'Select a', 'theme', 'Theme', 'New session', 'Restore', 'not found', 'error', 'Error'))]
        record = {'step':name,'bytes':len(value.encode('utf8')), 'final': 'FINAL_DESCRIPTION_SENTINEL' in text, 'selectedBg': '\x1b[48;2;58;58;74' in value, 'matches': matches[-12:]}
        events.append(record)
        print(mode, json.dumps(record, ensure_ascii=False))
        return record
    try:
        step('ready', wait=3.0)
        step('command', '/todo-details\r')
        step('expand plan', '\x1b[C')
        step('select build', '\x1b[B')
        step('expand build', '\x1b[C')
        for i in range(14):
            r = step(f'page down {i+1}', '\x1b[6~', .32)
            if r['final']: break
        step('resize 48x12', resize=(12,48), wait=.9)
        for i in range(16):
            r = step(f'narrow page down {i+1}', '\x1b[6~', .25)
            if r['final']: break
        step('resize 25x8', resize=(8,25), wait=.9)
        for i in range(20):
            r = step(f'short page down {i+1}', '\x1b[6~', .25)
            if r['final']: break
        step('restore geometry', resize=(35,100), wait=.8)
        step('escape', '\x1b')
        step('editor type', 'EDITOR_SENTINEL')
        step('editor clear', '\x15')
        step('reentry', '/todo-details\r')
        step('bracketed paste', '\x1b[200~PASTE_SENTINEL\x1b[201~')
        step('paste editor', wait=.6)
        step('clear editor', '\x15')
        step('reentry after paste', '/todo-details\r')
        step('other shortcut ctrl+l', '\x0c', .7)
        step('model picker down', '\x1b[B')
        step('model picker escape', '\x1b')
        step('escape todo after picker', '\x1b')
        step('session new command', '/new\r', 1.2)
        step('details after new', '/todo-details\r')
    finally:
        stop.set()
        if p.isalive(): p.terminate()
        t.join(timeout=3)
        (OUT / (mode + '.vt')).write_text(''.join(raw), encoding='utf-8')
        (OUT / (mode + '.json')).write_text(json.dumps(events, ensure_ascii=False, indent=2), encoding='utf-8')
        print('PROCESS', mode, 'terminated', not p.isalive(), 'capture', OUT)

print('ARTIFACT_DIR', OUT)
for mode in ('regular','fullscreen'):
    run(mode)
