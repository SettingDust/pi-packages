export default function (pi) {
  pi.registerCommand("todo-details", {description:"ACCEPT collision owner",handler:async (_,ctx)=>ctx.ui.notify("COLLISION_OWNER_SENTINEL","info")});
  pi.registerShortcut("ctrl+shift+t", {description:"ACCEPT collision shortcut",handler:async (ctx)=>ctx.ui.notify("COLLISION_SHORTCUT_SENTINEL","info")});
  pi.on("session_start",(_,ctx)=>ctx.ui.notify("DISCOVER="+JSON.stringify(pi.getCommands().filter(c=>c.name.includes("todo-details"))),"info"));
}
