import json, os, pathlib, re, shutil, tempfile, threading, time
from winpty import PtyProcess
base=pathlib.Path(tempfile.gettempdir())/'todo-inline-accept-446409dc'
out=pathlib.Path(tempfile.mkdtemp(prefix='todo-live-lifecycle-'))
print('ARTIFACT_DIR',out)
for mode in ('regular','fullscreen'):
    agent=out/(mode+'-agent');agent.mkdir()
    for name in ('auth.json','models-store.json','settings.json'):shutil.copyfile(base/'agent'/name,agent/name)
    fixture=out/(mode+'-fixture.jsonl');restore=out/(mode+'-restore.jsonl')
    shutil.copyfile(base/'fixture.jsonl',fixture);shutil.copyfile(base/'fixture.jsonl',restore)
    env=dict(os.environ,PI_CODING_AGENT_DIR=str(agent),PI_OFFLINE='1',PI_SKIP_VERSION_CHECK='1',PI_TELEMETRY='0',TODO_ACCEPT_RESTORE=str(restore))
    args=['node','node_modules/@earendil-works/pi-coding-agent/dist/cli.js','--session',str(fixture),'--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','-e',str(pathlib.Path(tempfile.gettempdir())/'todo-live-controls.ts'),'--tui-mode',mode]
    p=PtyProcess.spawn(args,cwd='E:/Projects/pi-packages',env=env,dimensions=(35,100))
    chunks=[];stop=threading.Event();events=[]
    def reader():
        while not stop.is_set():
            try:chunks.append(p.read(65536))
            except Exception:break
    t=threading.Thread(target=reader,daemon=True);t.start()
    def step(name,data=None,wait=.5):
        start=len(chunks)
        if data:p.write(data)
        time.sleep(wait)
        raw=''.join(chunks[start:]);plain=re.sub(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])','',raw).replace('\r','')
        match=[line for line in plain.splitlines() if any(s in line for s in ('ACCEPT','Todo details','Plan','Build','Todos ','SENTINEL','Live added','Replacement','Error','Session','Exception'))]
        e={'step':name,'bytes':len(raw.encode()),'matches':match[-15:],'selected': '\x1b[48;2;58;58;74' in raw};events.append(e);print(mode,json.dumps(e,ensure_ascii=False))
        (out/(mode+'-'+str(len(events))+'.vt')).write_text(raw,encoding='utf8')
    try:
        step('ready',wait=3);step('entry','/todo-details\r');step('plan right','\x1b[C');step('refresh add','/accept-add\r');step('refresh reentry','/todo-details\r');step('refresh escape','\x1b');step('set reset','/accept-set\r');step('set entry','/todo-details\r');step('set expand','\x1b[C');step('complete todos','/accept-terminal\r');step('terminal reentry','/todo-details\r');step('terminal timer wait',wait=5.7);step('down after clear','\x1b[B');step('editor after timer','TIMER_EDITOR_SENTINEL');step('clear editor','\x15');step('details absent','/todo-details\r');step('restore command','/accept-restore\r',wait=1.4);step('restore entry','/todo-details\r');step('restore expand','\x1b[C');step('off command','/accept-placement off\r',wait=1.4);step('off entry notice','/todo-details\r');step('off editor','OFF_EDITOR_SENTINEL');step('clear off editor','\x15');step('below command','/accept-placement belowEditor\r',wait=1.4);step('below entry notice','/todo-details\r');step('above restore','/accept-placement aboveEditor\r',wait=1.4);step('above entry','/todo-details\r');step('above escape','\x1b')
    finally:
        stop.set()
        if p.isalive():p.terminate()
        t.join(timeout=3)
        (out/(mode+'.vt')).write_text(''.join(chunks),encoding='utf8');(out/(mode+'.json')).write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf8');print('PROCESS',mode,'terminated',not p.isalive())
