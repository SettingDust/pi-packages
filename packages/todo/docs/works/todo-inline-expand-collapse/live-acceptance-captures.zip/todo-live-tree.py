import os, pathlib, tempfile, shutil, time, threading, re, json
from winpty import PtyProcess
base=pathlib.Path(tempfile.gettempdir())/'todo-inline-accept-446409dc'
out=pathlib.Path(tempfile.mkdtemp(prefix='todo-live-tree-'))
print('ARTIFACT_DIR',out)
for mode in ('regular','fullscreen'):
    agent=out/(mode+'-agent');agent.mkdir()
    for name in ('auth.json','models-store.json','settings.json'):shutil.copyfile(base/'agent'/name,agent/name)
    env=dict(os.environ,PI_CODING_AGENT_DIR=str(agent),PI_OFFLINE='1',PI_SKIP_VERSION_CHECK='1',PI_TELEMETRY='0')
    p=PtyProcess.spawn(['node','node_modules/@earendil-works/pi-coding-agent/dist/cli.js','--session',str(base/'fixture.jsonl'),'--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','-e','packages/todo/src/index.ts','--tui-mode',mode],cwd='E:/Projects/pi-packages',env=env,dimensions=(35,100))
    parts=[]; end=threading.Event(); events=[]
    def read():
        while not end.is_set():
            try:parts.append(p.read(65536))
            except Exception:break
    t=threading.Thread(target=read,daemon=True);t.start()
    def step(label,data=None,wait=.6):
        start=len(parts)
        if data:p.write(data)
        time.sleep(wait)
        raw=''.join(parts[start:]); text=re.sub(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])','',raw).replace('\r','')
        matches=[line for line in text.splitlines() if any(s in line for s in ('Plan','Build','Session Tree','session tree','Session tree','branch','Branch','Empty task','EDITOR_TREE','Warning'))]
        e={'step':label,'bytes':len(raw.encode()),'selection_sgr':'\x1b[48;2;58;58;74' in raw,'matches':matches[-12:]};events.append(e);print(mode,json.dumps(e,ensure_ascii=False))
    try:
        step('ready',wait=2.5);step('todo entry','/todo-details\r');step('expand plan','\x1b[C');step('tree command opens','/tree\r',wait=1);step('tree down','\x1b[B');step('tree escape','\x1b');step('todo reentry','/todo-details\r');step('todo escape','\x1b');step('editor after tree','EDITOR_TREE');step('clear','\x15')
    finally:
        end.set()
        if p.isalive():p.terminate()
        t.join(timeout=3)
        (out/(mode+'.vt')).write_text(''.join(parts),encoding='utf8');(out/(mode+'.json')).write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf8')
        print('PROCESS',mode,'terminated',not p.isalive())
