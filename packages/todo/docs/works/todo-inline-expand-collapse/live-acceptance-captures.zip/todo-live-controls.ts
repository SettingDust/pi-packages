import todo from "E:/Projects/pi-packages/packages/todo/src/index.ts";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
export default function (pi) {
  const tools = new Map();
  todo(new Proxy(pi, { get(target, key) {
    if (key === "registerTool") return (tool) => { tools.set(tool.name, tool); target.registerTool(tool); };
    return Reflect.get(target, key);
  }}));
  const run = async (name, params, ctx) => {
    const result = await tools.get(name).execute("acceptance-only", params, undefined, undefined, ctx);
    ctx.ui.notify("ACCEPT_" + name + "=" + result.details.result, "info");
    return result.details;
  };
  pi.registerCommand("accept-add", { handler: async (_,ctx) => run("todo_add", {task:"Plan", todos:[{name:"Live added",description:"REFRESH_DESCRIPTION_SENTINEL"}]},ctx) });
  pi.registerCommand("accept-set", { handler: async (_,ctx) => run("todo_set", {tasks:[{name:"Plan",todos:[{name:"Replacement",description:"SET_DESCRIPTION_SENTINEL"}]}]},ctx) });
  pi.registerCommand("accept-terminal", { handler: async (_,ctx) => {
    const view = await run("todo_view",{},ctx);
    await run("todo_transition",{transitions:view.snapshot.tasks.flatMap(task => task.todos.map(todo => ({task:task.name,todo:todo.name,status:"completed"})))},ctx);
  }});
  pi.registerCommand("accept-schedule", {handler: async (value,ctx) => {
    const action = value.trim();
    setTimeout(async () => {
      if (action === "add") await run("todo_add",{task:"Plan",todos:[{name:"Scheduled",description:"ASYNC_REFRESH_SENTINEL"}]},ctx);
      if (action === "set") await run("todo_set",{tasks:[{name:"Plan",todos:[{name:"Scheduled replacement",description:"ASYNC_SET_SENTINEL"}]}]},ctx);
      if (action === "empty") await run("todo_set",{tasks:[]},ctx);
    },2500);
  }});
  pi.registerCommand("accept-restore", {handler: async (_,ctx) => {
    await ctx.switchSession(process.env.TODO_ACCEPT_RESTORE);
  }});
  pi.registerCommand("accept-placement", {handler: async (value,ctx) => {
    await mkdir(join(process.env.PI_CODING_AGENT_DIR,"todo"),{recursive:true});
    await writeFile(join(process.env.PI_CODING_AGENT_DIR,"todo","settings.json"),JSON.stringify({widgetPlacement:value.trim()}));
    await ctx.switchSession(process.env.TODO_ACCEPT_RESTORE);
  }});
}
