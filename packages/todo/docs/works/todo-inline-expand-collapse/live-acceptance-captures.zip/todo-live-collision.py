import json, os, pathlib, re, shutil, tempfile, threading, time
from winpty import PtyProcess
base=pathlib.Path(tempfile.gettempdir())/'todo-inline-accept-446409dc'
out=pathlib.Path(tempfile.mkdtemp(prefix='todo-live-collision-'));print('ARTIFACT_DIR',out)
for mode in ('regular','fullscreen'):
    agent=out/(mode+'-agent');agent.mkdir()
    for name in ('auth.json','models-store.json','settings.json'):shutil.copyfile(base/'agent'/name,agent/name)
    fixture=out/(mode+'-fixture.jsonl');shutil.copyfile(base/'fixture.jsonl',fixture)
    env=dict(os.environ,PI_CODING_AGENT_DIR=str(agent),PI_OFFLINE='1',PI_SKIP_VERSION_CHECK='1',PI_TELEMETRY='0')
    p=PtyProcess.spawn(['node','node_modules/@earendil-works/pi-coding-agent/dist/cli.js','--session',str(fixture),'--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','-e','packages/todo/src/index.ts','-e',str(pathlib.Path(tempfile.gettempdir())/'todo-live-collision.ts'),'--tui-mode',mode],cwd='E:/Projects/pi-packages',env=env,dimensions=(35,100))
    chunks=[];stop=threading.Event();events=[]
    def reader():
        while not stop.is_set():
            try:chunks.append(p.read(65536))
            except Exception:break
    t=threading.Thread(target=reader,daemon=True);t.start()
    def step(name,data=None,wait=.6):
        start=len(chunks)
        if data:p.write(data)
        time.sleep(wait)
        raw=''.join(chunks[start:]);plain=re.sub(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])','',raw).replace('\r','')
        match=[line for line in plain.splitlines() if any(s in line for s in ('DISCOVER','todo-details','COLLISION','shortcut','Plan','Build','error','Error','Using '))]
        e={'step':name,'bytes':len(raw.encode()),'matches':match[-20:],'selected':'\x1b[48;2;58;58;74' in raw};events.append(e);print(mode,json.dumps(e,ensure_ascii=False));(out/(mode+'-'+str(len(events))+'.vt')).write_text(raw,encoding='utf8')
    try:
        step('ready',wait=3);step('completion prefix','/todo-d');step('completion tab','\t');step('completion dismiss','\x1b');step('clear completion','\x15');step('discovered qualified todo','/todo-details:1\r');step('expand','\x1b[C');step('escape','\x1b');step('discovered collision owner','/todo-details:2\r');step('shortcut lowercase kitty','\x1b[116;6u');step('shortcut uppercase kitty','\x1b[84;6u');step('editor afterwards','COLLISION_EDITOR_SENTINEL');step('clear','\x15')
    finally:
        stop.set()
        if p.isalive():p.terminate()
        t.join(timeout=3);(out/(mode+'.json')).write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf8');(out/(mode+'.vt')).write_text(''.join(chunks),encoding='utf8');print('PROCESS',mode,'terminated',not p.isalive())
