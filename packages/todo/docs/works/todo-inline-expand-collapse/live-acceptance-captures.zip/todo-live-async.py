import json, os, pathlib, re, shutil, tempfile, threading, time
from winpty import PtyProcess
base=pathlib.Path(tempfile.gettempdir())/'todo-inline-accept-446409dc';out=pathlib.Path(tempfile.mkdtemp(prefix='todo-live-async-'));print('ARTIFACT_DIR',out)
for mode in ('regular','fullscreen'):
    agent=out/(mode+'-agent');agent.mkdir()
    for name in ('auth.json','models-store.json','settings.json'):shutil.copyfile(base/'agent'/name,agent/name)
    fixture=out/(mode+'-fixture.jsonl');shutil.copyfile(base/'fixture.jsonl',fixture)
    env=dict(os.environ,PI_CODING_AGENT_DIR=str(agent),PI_OFFLINE='1',PI_SKIP_VERSION_CHECK='1',PI_TELEMETRY='0')
    p=PtyProcess.spawn(['node','node_modules/@earendil-works/pi-coding-agent/dist/cli.js','--session',str(fixture),'--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','-e',str(pathlib.Path(tempfile.gettempdir())/'todo-live-controls.ts'),'--tui-mode',mode],cwd='E:/Projects/pi-packages',env=env,dimensions=(35,100))
    chunks=[];stop=threading.Event();events=[]
    def reader():
        while not stop.is_set():
            try:chunks.append(p.read(65536))
            except Exception:break
    t=threading.Thread(target=reader,daemon=True);t.start()
    def step(name,data=None,wait=.35,size=None):
        start=len(chunks)
        if size:p.setwinsize(*size)
        if data:p.write(data)
        time.sleep(wait)
        raw=''.join(chunks[start:]);plain=re.sub(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)|[@-_])','',raw).replace('\r','')
        match=[line for line in plain.splitlines() if any(s in line for s in ('ACCEPT','Todo details','Plan','Build','Todos ','SENTINEL','Scheduled','Active','Finish','Step 01','Error','Exception'))]
        e={'step':name,'bytes':len(raw.encode()),'matches':match[-15:],'selected':'\x1b[48;2;58;58;74' in raw};events.append(e);print(mode,json.dumps(e,ensure_ascii=False));(out/(mode+'-'+str(len(events))+'.vt')).write_text(raw,encoding='utf8')
    try:
        step('ready',wait=3);step('entry','/todo-details\r');step('right','\x1b[C');step('left','\x1b[D');step('enter toggle','\r');step('space toggle',' ');step('space expand',' ');step('down','\x1b[B');step('build right','\x1b[C');step('up','\x1b[A');step('page up','\x1b[5~');step('repeated entry','/todo-details\r');step('exit','\x1b')
        step('schedule add','/accept-schedule add\r');step('active before refresh','/todo-details\r');step('observe asynchronous refresh',wait=2.3);step('editor after refresh','ASYNC_EDITOR_SENTINEL');step('clear','\x15');step('refresh entry','/todo-details\r');step('exit refresh','\x1b')
        step('schedule set','/accept-schedule set\r');step('active before set','/todo-details\r');step('observe asynchronous set',wait=2.3);step('set entry','/todo-details\r');step('set right','\x1b[C');step('set exit','\x1b')
        step('schedule removal','/accept-schedule empty\r');step('active before removal','/todo-details\r');step('observe asynchronous removal',wait=2.3);step('editor after removal','REMOVAL_EDITOR_SENTINEL');step('clear removal editor','\x15');step('absence notice','/todo-details\r')
        step('short resize',size=(7,25),wait=.7);step('short absent entry','/todo-details\r');step('restore geometry',size=(35,100),wait=.7)
    finally:
        stop.set()
        if p.isalive():p.terminate()
        t.join(timeout=3);(out/(mode+'.json')).write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf8');(out/(mode+'.vt')).write_text(''.join(chunks),encoding='utf8');print('PROCESS',mode,'terminated',not p.isalive())
